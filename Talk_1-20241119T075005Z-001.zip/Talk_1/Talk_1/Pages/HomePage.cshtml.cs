using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Talk_1.Pages
{
    public class HomePageModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
